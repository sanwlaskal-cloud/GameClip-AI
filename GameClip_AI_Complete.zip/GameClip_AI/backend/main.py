import os, re, json, time, uuid, shutil, zipfile, tempfile, subprocess, threading
from pathlib import Path
from typing import Optional
import requests
import numpy as np
import cv2
from fastapi import FastAPI, Header, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl

SUPABASE_URL = os.environ.get('SUPABASE_URL', '').rstrip('/')
SUPABASE_ANON_KEY = os.environ.get('SUPABASE_ANON_KEY', '')
FRONTEND_ORIGIN = os.environ.get('FRONTEND_ORIGIN', '*')
BUCKET = 'gameclip-uploads'
MAX_SOURCE_BYTES = 500 * 1024 * 1024
MAX_DURATION_SECONDS = 2 * 60 * 60
app = FastAPI(title='GameClip AI Processing API', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in FRONTEND_ORIGIN.split(',')] if FRONTEND_ORIGIN != '*' else ['*'], allow_credentials=False, allow_methods=['GET','POST','OPTIONS'], allow_headers=['Authorization','Content-Type'])

class ProcessRequest(BaseModel):
    job_id: str


def auth_headers(token: str):
    return {'apikey': SUPABASE_ANON_KEY, 'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}


def require_config():
    if not SUPABASE_URL or not SUPABASE_ANON_KEY:
        raise HTTPException(503, 'Backend is not configured with Supabase settings.')


def get_user(token: str):
    require_config()
    r = requests.get(f'{SUPABASE_URL}/auth/v1/user', headers=auth_headers(token), timeout=20)
    if r.status_code != 200:
        raise HTTPException(401, 'Your session is invalid. Please log in again.')
    return r.json()


def get_job(token: str, job_id: str, user_id: str):
    r = requests.get(f'{SUPABASE_URL}/rest/v1/video_jobs', params={'id':f'eq.{job_id}','select':'id,user_id,source_url,original_filename,output_path,status'}, headers=auth_headers(token), timeout=20)
    if r.status_code >= 300:
        raise RuntimeError(f'Could not read project: {r.text[:300]}')
    rows = r.json()
    if not rows or rows[0].get('user_id') != user_id:
        raise HTTPException(404, 'Project not found.')
    return rows[0]


def update_job(token: str, job_id: str, values: dict):
    h = auth_headers(token); h['Prefer'] = 'return=minimal'
    r = requests.patch(f'{SUPABASE_URL}/rest/v1/video_jobs', params={'id':f'eq.{job_id}'}, headers=h, json=values, timeout=30)
    if r.status_code >= 300:
        raise RuntimeError(f'Could not update project: {r.text[:300]}')


def signed_source_url(token: str, path: str) -> str:
    r = requests.post(f'{SUPABASE_URL}/storage/v1/object/sign/{BUCKET}/{path}', headers=auth_headers(token), json={'expiresIn':3600}, timeout=30)
    if r.status_code >= 300:
        raise RuntimeError(f'Could not access uploaded video: {r.text[:300]}')
    signed = r.json().get('signedURL') or r.json().get('signedUrl')
    if not signed:
        raise RuntimeError('Supabase did not return a signed video URL.')
    if signed.startswith('http'): return signed
    return f'{SUPABASE_URL}/storage/v1{signed if signed.startswith("/") else "/"+signed}'


def download_source(token: str, job: dict, work: Path) -> Path:
    if job.get('source_url'):
        url = job['source_url']
        if not re.match(r'^https?://(www\.)?(youtube\.com|youtu\.be)/', url, re.I):
            raise RuntimeError('Only YouTube video links are supported.')
        target = work / 'source.%(ext)s'
        cmd = ['yt-dlp','--no-playlist','--max-filesize','500M','-f','bv*[height<=1080]+ba/b[height<=1080]','--merge-output-format','mp4','-o',str(target),url]
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
        if p.returncode != 0:
            raise RuntimeError('YouTube download failed. Make sure the video is public and you own it or have permission. ' + (p.stderr[-700:] or p.stdout[-700:]))
        found = list(work.glob('source.*'))
        found = [x for x in found if x.is_file() and x.suffix not in ('.part','.ytdl')]
        if not found: raise RuntimeError('The YouTube video could not be downloaded.')
        source = found[0]
    else:
        path = job.get('output_path')
        if not path: raise RuntimeError('No uploaded video was attached to this project.')
        url = signed_source_url(token, path)
        source = work / 'source-video'
        with requests.get(url, stream=True, timeout=(20,300)) as r:
            if r.status_code >= 300: raise RuntimeError('Could not download your uploaded video from storage.')
            total = 0
            with open(source,'wb') as f:
                for chunk in r.iter_content(1024*1024):
                    if chunk:
                        total += len(chunk)
                        if total > MAX_SOURCE_BYTES: raise RuntimeError('Video is larger than the 500 MB processing limit.')
                        f.write(chunk)
    if not source.exists() or source.stat().st_size == 0: raise RuntimeError('Downloaded video is empty.')
    if source.stat().st_size > MAX_SOURCE_BYTES: raise RuntimeError('Video is larger than the 500 MB processing limit.')
    return source


def media_duration(path: Path) -> float:
    p = subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],capture_output=True,text=True,timeout=30)
    if p.returncode: raise RuntimeError('This video format could not be read.')
    duration = float(p.stdout.strip())
    if duration <= 0 or duration > MAX_DURATION_SECONDS: raise RuntimeError('Video must be between 1 second and 2 hours long.')
    return duration


def activity_scores(path: Path, duration: float):
    # Local, no-API activity scoring: combine audio RMS and frame-to-frame visual change.
    audio = subprocess.Popen(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','8000','-f','s16le','-'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    raw, _ = audio.communicate(timeout=600)
    if audio.returncode not in (0, None): raw = b''
    samples = np.frombuffer(raw,dtype=np.int16).astype(np.float32)
    rate = 8000
    seconds = max(1,int(np.ceil(duration)))
    audio_score = np.zeros(seconds,dtype=np.float32)
    per = rate
    for i in range(seconds):
        seg = samples[i*per:(i+1)*per]
        if len(seg): audio_score[i] = np.sqrt(np.mean(seg*seg))
    cap = cv2.VideoCapture(str(path))
    visual = np.zeros(seconds,dtype=np.float32)
    prev = None; sec = -1
    while True:
        ok, frame = cap.read()
        if not ok: break
        pos = cap.get(cv2.CAP_PROP_POS_MSEC)/1000.0
        current_sec = int(pos)
        if current_sec >= seconds: break
        if current_sec != sec:
            small = cv2.resize(frame,(96,54),interpolation=cv2.INTER_AREA)
            gray = cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
            if prev is not None and current_sec >= 0:
                visual[current_sec] = max(visual[current_sec],float(np.mean(cv2.absdiff(prev,gray))))
            prev = gray; sec = current_sec
    cap.release()
    def norm(a):
        if not np.any(a): return a
        hi = np.percentile(a,95)
        return np.clip(a/(hi if hi > 0 else 1),0,1)
    return 0.65*norm(audio_score)+0.35*norm(visual)


def choose_segments(scores: np.ndarray, duration: float, clip_len: int=30, count: int=3):
    if duration <= clip_len + 5:
        return [(0.0,max(1.0,duration))]
    n = len(scores); window = max(5,int(clip_len)); candidates=[]
    # Score 1-second bins with a slight preference for strong peaks.
    for start in range(0,max(1,n-window+1),3):
        end=min(n,start+window)
        s=scores[start:end]
        if len(s): candidates.append((float(np.mean(s)+0.25*np.max(s)),float(start)))
    candidates.sort(reverse=True)
    chosen=[]
    for score,start in candidates:
        if all(abs(start-old)>=window*0.8 for old in chosen): chosen.append(start)
        if len(chosen)>=count: break
    if not chosen: chosen=[max(0,(n-window)//2)]
    return [(s,min(float(window),duration-s)) for s in sorted(chosen)]


def render_clips(source: Path, work: Path):
    duration=media_duration(source)
    scores=activity_scores(source,duration)
    segments=choose_segments(scores,duration)
    outdir=work/'clips'; outdir.mkdir()
    for i,(start,length) in enumerate(segments,1):
        out=outdir/f'gameclip_short_{i}.mp4'
        vf='scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setsar=1,fps=30'
        cmd=['ffmpeg','-y','-ss',f'{start:.2f}','-i',str(source),'-t',f'{length:.2f}','-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','24','-c:a','aac','-b:a','128k','-movflags','+faststart',str(out)]
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=900)
        if p.returncode: raise RuntimeError('FFmpeg could not render a clip: '+p.stderr[-500:])
    archive=work/'gameclip_shorts.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(outdir.glob('*.mp4')): z.write(f,f.name)
    return archive


def upload_result(token: str, user_id: str, job_id: str, archive: Path):
    path=f'{user_id}/{job_id}/gameclip_shorts.zip'
    headers=auth_headers(token); headers.update({'Content-Type':'application/zip','x-upsert':'true'})
    with open(archive,'rb') as f:
        r=requests.post(f'{SUPABASE_URL}/storage/v1/object/{BUCKET}/{path}',headers=headers,data=f,timeout=300)
    if r.status_code >= 300: raise RuntimeError('Could not save the finished clips: '+r.text[:400])
    return path


def worker(token: str, user_id: str, job_id: str):
    try:
        job=get_job(token,job_id,user_id)
        update_job(token,job_id,{'status':'processing','error_message':None})
        with tempfile.TemporaryDirectory(prefix='gameclip-') as tmp:
            work=Path(tmp)
            source=download_source(token,job,work)
            archive=render_clips(source,work)
            output_path=upload_result(token,user_id,job_id,archive)
        update_job(token,job_id,{'status':'completed','output_path':output_path,'error_message':None,'updated_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    except Exception as e:
        try: update_job(token,job_id,{'status':'failed','error_message':str(e)[:900],'updated_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
        except Exception: pass

@app.get('/health')
def health(): return {'ok':True,'service':'gameclip-api','processing':'enabled','method':'local audio/visual activity scoring + FFmpeg'}

@app.post('/api/process')
def process(req: ProcessRequest, background: BackgroundTasks, authorization: Optional[str]=Header(default=None)):
    if not authorization or not authorization.lower().startswith('bearer '): raise HTTPException(401,'Please log in first.')
    token=authorization.split(' ',1)[1]
    user=get_user(token)
    job=get_job(token,req.job_id,user['id'])
    if job['status']=='processing': return {'ok':True,'status':'processing','job_id':req.job_id}
    if job['status']=='completed': return {'ok':True,'status':'completed','job_id':req.job_id}
    background.add_task(worker,token,user['id'],req.job_id)
    return {'ok':True,'status':'queued','job_id':req.job_id}

@app.get('/api/jobs/{job_id}')
def job_status(job_id: str, authorization: Optional[str]=Header(default=None)):
    if not authorization or not authorization.lower().startswith('bearer '): raise HTTPException(401,'Please log in first.')
    token=authorization.split(' ',1)[1]; user=get_user(token); job=get_job(token,job_id,user['id'])
    return {'id':job['id'],'status':job['status'],'error_message':job.get('error_message'),'has_output':bool(job.get('output_path')) and job['status']=='completed'}

@app.get('/api/download/{job_id}')
def download(job_id: str, authorization: Optional[str]=Header(default=None)):
    if not authorization or not authorization.lower().startswith('bearer '): raise HTTPException(401,'Please log in first.')
    token=authorization.split(' ',1)[1]; user=get_user(token); job=get_job(token,job_id,user['id'])
    if job['status']!='completed' or not job.get('output_path'): raise HTTPException(409,'Your clips are not ready yet.')
    return {'url':signed_source_url(token,job['output_path'])}
