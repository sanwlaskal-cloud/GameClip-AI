// Public browser settings only. Never put a Supabase service_role/secret key here.
window.GAMECLIP_CONFIG = {
  url: "https://sykrovrsltvsbqyhechq.supabase.co",
  publishableKey: "sb_publishable_beYLbTWbiW5gl3uG-gXUow_E6_eOtbd",
  // This endpoint becomes active after the Python backend is deployed to Railway.
  apiBase: "https://gameclip-api-production.up.railway.app"
};
