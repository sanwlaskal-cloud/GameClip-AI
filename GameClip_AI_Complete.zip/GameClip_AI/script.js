// GameClip AI frontend — Supabase Auth, private uploads, processing and project history.
const CONFIG = window.GAMECLIP_CONFIG || {};
const clientReady = Boolean(window.supabase && CONFIG.url && CONFIG.publishableKey);
const supabase = clientReady ? window.supabase.createClient(CONFIG.url, CONFIG.publishableKey) : null;
const API_BASE = (CONFIG.apiBase || "").replace(/\/$/, "");
const $ = (id) => document.getElementById(id);
const modal = $("auth-modal");
let authMode = "login";
let currentUser = null;
let pollHandle = null;

function message(text, bad=false) {
  const el = $("form-message"); el.textContent = text;
  el.style.color = bad ? "#ff91a4" : "#9de2bd";
}
function openAuth(mode) {
  authMode = mode;
  const signup = mode === "signup";
  $("modal-title").textContent = signup ? "Create your account" : "Log in";
  $("modal-kicker").textContent = signup ? "JOIN THE COMMUNITY" : "WELCOME BACK";
  $("modal-copy").textContent = signup ? "Create an account to access your workspace." : "Your gaming highlights are waiting.";
  $("auth-submit").textContent = signup ? "Create account" : "Continue";
  $("switch-auth").textContent = signup ? "Already have an account? Log in" : "Need an account? Sign up";
  modal.classList.add("open"); modal.setAttribute("aria-hidden","false");
}
function closeAuth(){ modal.classList.remove("open"); modal.setAttribute("aria-hidden","true"); }
document.querySelectorAll("[data-modal]").forEach(b=>b.addEventListener("click",()=>openAuth(b.dataset.modal)));
$("modal-close").addEventListener("click",closeAuth);
modal.addEventListener("click",e=>{if(e.target===modal)closeAuth();});
$("switch-auth").addEventListener("click",()=>openAuth(authMode==="login"?"signup":"login"));

$("auth-form").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!supabase){alert("Supabase config missing. Check config.js.");return;}
  const email=$("auth-email").value.trim(), password=$("auth-password").value;
  $("auth-submit").disabled=true;
  try{
    const result = authMode==="signup"
      ? await supabase.auth.signUp({email,password,options:{emailRedirectTo:window.location.origin}})
      : await supabase.auth.signInWithPassword({email,password});
    if(result.error) throw result.error;
    if(authMode==="signup" && !result.data.session){
      $("auth-note").textContent="Account created. Check your email to confirm your address, then log in.";
      return;
    }
    closeAuth(); await refreshSession();
  }catch(err){$("auth-note").textContent=err.message||"Authentication failed.";}
  finally{$("auth-submit").disabled=false;}
});

async function apiFetch(path, options={}){
  if(!API_BASE) throw new Error("Processing API address is not configured.");
  const {data:{session}}=await supabase.auth.getSession();
  if(!session?.access_token) throw new Error("Your login session expired. Please log in again.");
  const response=await fetch(`${API_BASE}${path}`,{...options,headers:{"Content-Type":"application/json","Authorization":`Bearer ${session.access_token}`,...(options.headers||{})}});
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.detail||data.error||`Processing server error (${response.status}).`);
  return data;
}
async function startProcessing(jobId){
  try{
    await apiFetch("/api/process",{method:"POST",body:JSON.stringify({job_id:jobId})});
    message("Video received. Finding active moments and creating vertical Shorts…");
    await loadJobs();
  }catch(err){
    message(`Project saved, but processing could not start: ${err.message}`,true);
    await loadJobs();
  }
}
async function refreshSession(){
  if(!supabase){$("signed-out-note").textContent="Website configuration missing.";return;}
  const {data:{session}}=await supabase.auth.getSession();
  currentUser=session?.user||null;
  $("signed-out-note").classList.toggle("hidden",!!currentUser);
  $("workspace").classList.toggle("hidden",!currentUser);
  $("nav-auth").innerHTML = currentUser
    ? `<span class="nav-user">${escapeHtml(currentUser.email||"Signed in")}</span><a class="btn btn-small btn-primary" href="#creator">My workspace</a>`
    : `<button class="btn btn-ghost" data-modal="login">Log in</button><button class="btn btn-small btn-primary" data-modal="signup">Sign up</button>`;
  $("nav-auth").querySelectorAll("[data-modal]").forEach(b=>b.addEventListener("click",()=>openAuth(b.dataset.modal)));
  if(currentUser){$("user-email").textContent=currentUser.email||"Signed in";await loadJobs();startPolling();}
  else stopPolling();
}
function startPolling(){if(pollHandle)clearInterval(pollHandle);pollHandle=setInterval(()=>{if(currentUser)loadJobs();},10000);}
function stopPolling(){if(pollHandle)clearInterval(pollHandle);pollHandle=null;}
$("logout").addEventListener("click",async()=>{stopPolling();await supabase.auth.signOut();await refreshSession();});
$("refresh-jobs").addEventListener("click",loadJobs);
function validYoutube(value){
  try{const u=new URL(value);return ["youtube.com","www.youtube.com","m.youtube.com","youtu.be"].includes(u.hostname) && (u.hostname==="youtu.be" ? u.pathname.length>1 : (u.pathname==="/watch" ? u.searchParams.has("v") : u.pathname.startsWith("/shorts/")||u.pathname.startsWith("/embed/")));}catch{return false;}
}
$("link-form").addEventListener("submit",async e=>{
  e.preventDefault(); if(!currentUser)return;
  const url=$("video-link").value.trim();
  if(!validYoutube(url)){message("Please enter a valid YouTube video URL.",true);return;}
  const btn=e.submitter;btn.disabled=true;
  try{
    const {data,error}=await supabase.from("video_jobs").insert({user_id:currentUser.id,source_url:url,status:"queued"}).select("id").single();
    if(error)throw error;
    $("video-link").value="";
    await startProcessing(data.id);
  }catch(err){message(err.message||"Could not save this link.",true);}
  finally{btn.disabled=false;}
});
$("video-file").addEventListener("change",async e=>{
  const file=e.target.files[0]; if(!file||!currentUser)return;
  const allowed=["video/mp4","video/quicktime","video/webm","video/x-matroska"];
  if(!allowed.includes(file.type)){message("Unsupported video format. Use MP4, MOV, WebM or MKV.",true);e.target.value="";return;}
  if(file.size>500*1024*1024){message("File is larger than the 500 MB limit.",true);e.target.value="";return;}
  const path=`${currentUser.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  message("Uploading video…");
  try{
    const {error:uploadError}=await supabase.storage.from("gameclip-uploads").upload(path,file,{contentType:file.type,upsert:false});
    if(uploadError)throw uploadError;
    const {data,error:jobError}=await supabase.from("video_jobs").insert({user_id:currentUser.id,original_filename:file.name,output_path:path,status:"queued"}).select("id").single();
    if(jobError)throw jobError;
    e.target.value="";
    await startProcessing(data.id);
  }catch(err){message(err.message||"Upload failed.",true);e.target.value="";}
});
async function downloadJob(jobId){
  try{const data=await apiFetch(`/api/download/${encodeURIComponent(jobId)}`);window.location.href=data.url;}
  catch(err){message(err.message||"Could not download clips.",true);}
}
async function loadJobs(){
  if(!currentUser)return;
  const list=$("jobs-list");list.innerHTML="<p class='hint'>Loading projects…</p>";
  const {data,error}=await supabase.from("video_jobs").select("id,source_url,original_filename,status,created_at,error_message,output_path").order("created_at",{ascending:false}).limit(30);
  if(error){list.textContent=error.message;return;}
  if(!data.length){list.innerHTML="<p class='hint'>No projects yet. Add your first video above.</p>";return;}
  list.innerHTML=data.map(job=>{
    const title=escapeHtml(job.original_filename||job.source_url||"Video project");
    const errorText=job.status==="failed"&&job.error_message?`<small class="error">${escapeHtml(job.error_message)}</small>`:"";
    const download=job.status==="completed"?`<button class="btn btn-small btn-primary" data-download="${escapeHtml(job.id)}">Download Shorts ↓</button>`:"";
    return `<article class="job-card"><div class="job-info"><strong>${title}</strong><small>${new Date(job.created_at).toLocaleString()}</small>${errorText}</div><span class="status ${escapeHtml(job.status)}">${escapeHtml(job.status)}</span>${download}</article>`;
  }).join("");
  list.querySelectorAll("[data-download]").forEach(b=>b.addEventListener("click",()=>downloadJob(b.dataset.download)));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
if(supabase){supabase.auth.onAuthStateChange(()=>setTimeout(refreshSession,0));refreshSession();}
else {$("signed-out-note").textContent="Supabase settings missing. Add the project URL and publishable key in config.js."; $("signed-out-note").classList.remove("hidden");}
