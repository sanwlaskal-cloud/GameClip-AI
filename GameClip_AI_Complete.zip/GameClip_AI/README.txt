GAMECLIP AI — COMPLETE SOURCE PACKAGE (FRONTEND + PROCESSING API)

WHAT IS INCLUDED
- index.html, style.css, script.js, config.js: website frontend
- backend/main.py: authenticated API and background processing worker
- backend/Dockerfile: installs FFmpeg and yt-dlp, then starts FastAPI
- backend/requirements.txt: pinned Python dependencies

WHAT THE PROCESSOR DOES
- Accepts a user's own uploaded video or an accessible YouTube URL.
- Checks the logged-in Supabase user and verifies that the job belongs to them.
- Downloads the source, scores one-second segments using audio loudness and visual frame changes,
  selects up to three non-overlapping moments, and renders 9:16 MP4 clips with FFmpeg.
- Saves a ZIP of the clips in the existing private gameclip-uploads bucket.
- Updates the user's job status; the website polls status and offers a download link.

IMPORTANT: THIS PACKAGE IS BUILT BUT THE NEW WORKER IS NOT DEPLOYED YET.
The existing Railway gameclip-api service is still using its previous generic function image.
The live site will not start processing until backend/ is deployed to that Railway service and
its environment variables are configured. No live deployment is claimed in this package.

DEPLOY THE PROCESSING API TO RAILWAY
1. Extract this ZIP on your computer.
2. In Railway, open project "GameClip AI" and service "gameclip-api".
3. Connect this folder's backend directory as the service source (for example, push the extracted
   project to a GitHub repository and select that repository with backend as the root directory,
   or deploy the backend directory with Railway CLI).
4. Set these service variables in Railway:
   SUPABASE_URL=https://sykrovrsltvsbqyhechq.supabase.co
   SUPABASE_ANON_KEY=<your Supabase publishable/anon key>
   FRONTEND_ORIGIN=https://genuine-sunshine-aea0e9.netlify.app
   PORT=8080
   The Supabase publishable key is safe for this authenticated API design. NEVER put a
   service_role/secret key in this project or in the browser.
5. Deploy. Verify https://gameclip-api-production.up.railway.app/health returns JSON with
   "ok": true and "processing": "enabled".
6. Upload the root frontend files (index.html, style.css, script.js, config.js) to the existing
   Netlify site. config.js already contains the existing public Supabase URL/key and API URL.

SUPABASE
- Existing profiles/video_jobs tables and RLS are retained.
- Existing private gameclip-uploads bucket is retained. application/zip was added to its
  allowed MIME types so the generated Shorts archive can be stored.
- No service_role key is used. The API verifies the user's bearer token and accesses only that
  user's own job and storage path.

PROCESSING NOTES / LIMITATIONS
- Highlight selection is a lightweight open-source heuristic (audio energy + visual change),
  not a trained game-specific AI model. It does not understand kills, wins, speech, or game events.
- Vertical output currently center-crops to 720x1280; it does not track a moving player or add
  subtitles. Up to three 30-second clips are generated.
- YouTube processing depends on the video being publicly accessible and yt-dlp being able to
  retrieve it. Respect YouTube terms, copyright, privacy, and only process videos you own or
  have permission to use. Some videos will not be downloadable.
- Long videos need CPU, RAM, disk, and time. Railway resource limits and usage charges apply;
  check your Railway plan before processing large videos. The worker runs in the API container,
  so a service restart can interrupt a job.
- Do not upload private credentials or a Supabase service_role key.

LOCAL SYNTAX CHECK
Python syntax was checked when this package was assembled. A full cloud video test requires a
successfully deployed Railway worker and a permitted sample video.
